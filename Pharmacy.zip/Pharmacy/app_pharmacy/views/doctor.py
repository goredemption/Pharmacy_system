import json
import random
from datetime import datetime
from django.shortcuts import render, HttpResponse, get_object_or_404, redirect
from django.utils.timezone import now
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt


from app_pharmacy import models
from app_pharmacy.utils.bootstrap import BootStrapModelForm
from app_pharmacy.utils.pagination import Pagination
from django.utils.safestring import mark_safe



class PatientModelForm(BootStrapModelForm):
    class Meta:
        model = models.Patient
        fields = "__all__"


def patient_list(request):
    data_dict = {}
    search_data = request.GET.get('q', "")
    if search_data:
        data_dict["name__contains"] = search_data
    queryset = models.Patient.objects.filter(**data_dict).order_by('id')
    page_object = Pagination(request, queryset)
    form = PatientModelForm()
    context = {
        'form': form,
        "queryset": page_object.page_queryset,  # 分完页的数据
        "page_string": page_object.html()  # 生成页码
    }

    return render(request, 'd_patient_list.html', context)

class PatientAddModelForm(BootStrapModelForm):
    class Meta:
        model = models.Patient
        exclude = ["modify_time"]

def patient_delete(request, nid):
    models.Drug.objects.filter(id=nid).delete()
    return redirect('/pill/list/')

def patient_add(request):
    """ 添加靓号 """
    if request.method == "GET":
        form = PatientAddModelForm()
        return render(request, 'd_patient_add.html', {"form": form})

    form = PatientAddModelForm(data=request.POST)
    form.instance.modify_time = now()
    if form.is_valid():
        form.save()
        return redirect('/patient/list/')
    return render(request, 'd_patient_add.html', {"form": form})

def patient_edit(request, nid):
    """ 编辑靓号 """
    row_object = models.Patient.objects.filter(id=nid).first()

    if request.method == "GET":
        form = PatientModelForm(instance=row_object)
        return render(request, 'd_patient_edit.html', {"form": form})

    form = PatientModelForm(data=request.POST, instance=row_object)
    if form.is_valid():
        form.save()
        return redirect('/patient/list/')

    return render(request, 'd_patient_edit.html', {"form": form})


def patient_delete(request, nid):
    models.Patient.objects.filter(id=nid).delete()
    return redirect('/patient/list/')

class PrescriptionModelForm(BootStrapModelForm):
    class Meta:
        model = models.Prescription
        exclude = ["date", "doctor"]

@csrf_exempt
def prescription_add(request):
    """ 新建订单（Ajax请求）"""
    form = PrescriptionModelForm(data=request.POST)
    if form.is_valid():
        # 处方日期
        form.instance.date = now()

        # 医生姓名
        user_info = request.session.get("info")
        user_id = user_info.get('id')

        doctor = get_object_or_404(models.Doctor, user_id=user_id)
        form.instance.doctor = doctor

        # 保存到数据库中
        form.save()
        return JsonResponse({"status": True})
    return JsonResponse({"status": False, 'error': form.errors})

def prescription_detail(request):
    uid = request.GET.get("uid")
    row_dict = models.Prescription.objects.filter(id=uid).values('medication', 'patient', 'notes').first()
    if not row_dict:
        return JsonResponse({"status": False, 'error': "数据不存在。"})

    # 从数据库中获取到一个对象 row_object
    result = {
        "status": True,
        "data": row_dict
    }
    return JsonResponse(result)

# 根据自己登陆信息中的用户名，显示自己所开的处方
def prescribe(request):

    user_info = request.session.get("info")
    user_id = user_info.get('id')

    doctor_ids = models.Doctor.objects.filter(user=user_id).values_list('id', flat=True)
    data_dic = {'doctor__id__in': doctor_ids}
    queryset = models.Prescription.objects.filter(**data_dic).order_by('id')

    page_object = Pagination(request, queryset)
    form = PrescriptionModelForm()
    context = {
        'form': form,
        "queryset": page_object.page_queryset,  # 分完页的数据
        "page_string": page_object.html()  # 生成页码
    }
    return render(request, 'd_prescribe.html', context)


def prescription_delete(request):
    """ 删除订单 """
    uid = request.GET.get('uid')
    exists = models.Prescription.objects.filter(id=uid).exists()
    if not exists:
        return JsonResponse({"status": False, 'error': "删除失败，数据不存在。"})

    models.Prescription.objects.filter(id=uid).delete()
    return JsonResponse({"status": True})

@csrf_exempt
def prescription_edit(request):
    """ 编辑订单 """
    uid = request.GET.get("uid")
    row_object = models.Prescription.objects.filter(id=uid).first()
    if not row_object:
        return JsonResponse({"status": False, 'tips': "数据不存在，请刷新重试。"})

    form = PrescriptionModelForm(data=request.POST, instance=row_object)
    if form.is_valid():
        # 处方日期
        form.instance.date = now()

        # 医生姓名
        user_info = request.session.get("info")
        user_id = user_info.get('id')

        doctor = get_object_or_404(models.Doctor, user_id=user_id)
        form.instance.doctor = doctor
        form.save()
        return JsonResponse({"status": True})

    return JsonResponse({"status": False, 'error': form.errors})

class CategoryModelForm(BootStrapModelForm):
    class Meta:
        model = models.Category
        exclude = ["modify_time", "doctor"]


def drug_sort(request):
    queryset = models.Category.objects.all().order_by('id')
    page_object = Pagination(request, queryset)
    form = CategoryModelForm()
    context = {
        'form': form,
        "queryset": page_object.page_queryset,  # 分完页的数据
        "page_string": page_object.html()  # 生成页码
    }
    return render(request, 'd_drug_sort.html', context)


@csrf_exempt
def drug_sort_add(request):
    """ 新建订单（Ajax请求）"""
    form = CategoryModelForm(data=request.POST)
    if form.is_valid():
        # 处方日期
        form.instance.modify_time = now()

        # 医生姓名
        user_info = request.session.get("info")
        user_id = user_info.get('id')

        doctor = get_object_or_404(models.Doctor, user_id=user_id)
        form.instance.doctor = doctor

        # 保存到数据库中
        form.save()
        return JsonResponse({"status": True})
    return JsonResponse({"status": False, 'error': form.errors})

def drug_sort_delete(request):
    """ 删除订单 """
    uid = request.GET.get('uid')
    exists = models.Category.objects.filter(id=uid).exists()
    if not exists:
        return JsonResponse({"status": False, 'error': "删除失败，数据不存在。"})

    models.Category.objects.filter(id=uid).delete()
    return JsonResponse({"status": True})

@csrf_exempt
def drug_sort_edit(request):
    """ 编辑订单 """
    uid = request.GET.get("uid")
    row_object = models.Category.objects.filter(id=uid).first()
    if not row_object:
        return JsonResponse({"status": False, 'tips': "数据不存在，请刷新重试。"})

    form = CategoryModelForm(data=request.POST, instance=row_object)
    if form.is_valid():
        # 处方日期
        form.instance.modify_time = now()

        # 医生姓名
        user_info = request.session.get("info")
        user_id = user_info.get('id')

        doctor = get_object_or_404(models.Doctor, user_id=user_id)
        form.instance.doctor = doctor
        form.save()
        return JsonResponse({"status": True})

    return JsonResponse({"status": False, 'error': form.errors})


def drug_sort_detail(request):
    uid = request.GET.get("uid")
    row_dict = models.Category.objects.filter(id=uid).values('name', 'description', 'access').first()
    if not row_dict:
        return JsonResponse({"status": False, 'error': "数据不存在。"})

    # 从数据库中获取到一个对象 row_object
    result = {
        "status": True,
        "data": row_dict
    }
    return JsonResponse(result)

class PillModelForm(BootStrapModelForm):
    class Meta:
        model = models.Drug
        exclude = ["modify_time"]

def pill_list(request):
    data_dict = {}
    search_data = request.GET.get('q', "")
    if search_data:
        data_dict["name__contains"] = search_data

    queryset = models.Drug.objects.filter(**data_dict).order_by('-id')

    page_object = Pagination(request, queryset)
    form = PillModelForm()
    context = {
        "search_data": search_data,
        'form': form,
        "queryset": page_object.page_queryset,  # 分完页的数据
        "page_string": page_object.html()  # 生成页码
    }

    return render(request, 'd_pill_list.html', context)

def pill_add(request):
    """ 添加药品 """
    if request.method == "GET":
        form = PillModelForm()
        return render(request, 'd_pill_add.html', {"form": form})

    form = PillModelForm(data=request.POST)
    form.instance.modify_time = now()
    if form.is_valid():
        form.save()
        return redirect('/pill/list/')
    return render(request, 'd_pill_add.html', {"form": form})

def pill_delete(request):
    """ 删除订单 """
    uid = request.GET.get('uid')
    exists = models.Drug.objects.filter(id=uid).exists()
    if not exists:
        return JsonResponse({"status": False, 'error': "删除失败，数据不存在。"})

    models.Drug.objects.filter(id=uid).delete()
    return JsonResponse({"status": True})

@csrf_exempt
def pill_edit(request):
    """ 编辑订单 """
    uid = request.GET.get("uid")
    row_object = models.Drug.objects.filter(id=uid).first()
    if not row_object:
        return JsonResponse({"status": False, 'tips': "数据不存在，请刷新重试。"})

    form = PillModelForm(data=request.POST, instance=row_object)
    if form.is_valid():
        form.instance.modify_time = now()

        form.save()
        return JsonResponse({"status": True})

    return JsonResponse({"status": False, 'error': form.errors})


def pill_detail(request):
    uid = request.GET.get("uid")
    row_dict = models.Drug.objects.filter(id=uid).values('name', 'dose', 'effect', 'price', 'category', 'supplier', 'inventory').first()
    if not row_dict:
        return JsonResponse({"status": False, 'error': "数据不存在。"})

    # 从数据库中获取到一个对象 row_object
    result = {
        "status": True,
        "data": row_dict
    }
    return JsonResponse(result)







