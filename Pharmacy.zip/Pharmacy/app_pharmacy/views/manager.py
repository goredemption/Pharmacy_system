import json
import random
from datetime import datetime
from django.shortcuts import render, HttpResponse, get_object_or_404
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django import forms
from django.utils.timezone import now
from app_pharmacy.utils.encrypt import md5
from django.core.exceptions import ValidationError
from django.db.models import Sum


from app_pharmacy import models
from app_pharmacy.utils.bootstrap import BootStrapModelForm
from app_pharmacy.utils.pagination import Pagination
from django.utils.safestring import mark_safe



class SalesModelForm(BootStrapModelForm):
    class Meta:
        model = models.Sales
        fields = "__all__"


def sales_list(request):
    queryset = models.Sales.objects.all().order_by('id')
    page_object = Pagination(request, queryset)
    form = SalesModelForm()
    context = {
        'form': form,
        "queryset": page_object.page_queryset,  # 分完页的数据
        "page_string": page_object.html()  # 生成页码
    }

    return render(request, 'm_sales_list.html', context)


class UserModelForm(BootStrapModelForm):
    class Meta:
        model = models.User
        fields = "__all__"

class UserModifyModelForm(BootStrapModelForm):
    confirm_password = forms.CharField(
        label="确认密码",
        widget=forms.PasswordInput(render_value=True)
    )

    class Meta:
        model = models.User
        fields = ["username", 'password', "confirm_password", "role"]
        widgets = {
            "password": forms.PasswordInput(render_value=True)
        }

    def clean_password(self):
        pwd = self.cleaned_data.get("password")
        return md5(pwd)

    def clean_confirm_password(self):
        pwd = self.cleaned_data.get("password")
        confirm = md5(self.cleaned_data.get("confirm_password"))
        if confirm != pwd:
            raise ValidationError("密码不一致")
        # 返回什么，此字段以后保存到数据库就是什么。
        return confirm

def user_list(request):
    queryset = models.User.objects.all().order_by('id')
    page_object = Pagination(request, queryset)
    form = UserModifyModelForm()
    context = {
        'form': form,
        "queryset": page_object.page_queryset,  # 分完页的数据
        "page_string": page_object.html()  # 生成页码
    }
    return render(request, 'm_user_list.html', context)



def user_detail(request):
    uid = request.GET.get("uid")
    row_dict = models.User.objects.filter(id=uid).values('username', 'role').first()
    if not row_dict:
        return JsonResponse({"status": False, 'error': "数据不存在。"})

    # 从数据库中获取到一个对象 row_object
    result = {
        "status": True,
        "data": row_dict
    }
    return JsonResponse(result)

def user_delete(request):
    """ 删除订单 """
    uid = request.GET.get('uid')
    exists = models.User.objects.filter(id=uid).exists()
    if not exists:
        return JsonResponse({"status": False, 'error': "删除失败，数据不存在。"})

    models.User.objects.filter(id=uid).delete()
    return JsonResponse({"status": True})

@csrf_exempt
def user_edit(request):
    """ 编辑订单 """
    uid = request.GET.get("uid")
    row_object = models.User.objects.filter(id=uid).first()
    if not row_object:
        return JsonResponse({"status": False, 'tips': "数据不存在，请刷新重试。"})

    form = UserModifyModelForm(data=request.POST, instance=row_object)
    if form.is_valid():
        form.save()
        return JsonResponse({"status": True})

    return JsonResponse({"status": False, 'error': form.errors})


def chart_bar(request):
    """ 获取销售数前三的医生 """
    # 查询每个医生的总销售金额
    sales_data = models.Sales.objects.values('doctor__name').annotate(total_sales=Sum('amount')).order_by('-total_sales')[:3]

    # 准备数据格式
    legend = [item['doctor__name'] for item in sales_data]
    series_list = [
        {
            "name": item['doctor__name'],
            "type": 'bar',
            "data": [item['total_sales']]  # 假设你需要每个医生的总销售金额
        }
        for item in sales_data
    ]
    x_axis = ['总销售额']  # 假设x轴只是显示总销售额

    result = {
        "status": True,
        "data": {
            'legend': legend,
            'series_list': series_list,
            'x_axis': x_axis,
        }
    }

    return JsonResponse(result)


def drug_bar(request):
    """ 获取药品销售信息以显示条形图 """
    # 查询每种药品的总销售金额
    sales_data = models.Sales.objects.values('drug__name').annotate(total_sales=Sum('amount')).order_by('-total_sales')

    # 准备数据格式
    legend = [item['drug__name'] for item in sales_data]
    series_list = [
        {
            "name": "药品销售额",
            "type": 'bar',
            "data": [item['total_sales'] for item in sales_data]
        }
    ]
    x_axis = [item['drug__name'] for item in sales_data]

    result = {
        "status": True,
        "data": {
            'legend': legend,
            'series_list': series_list,
            'x_axis': x_axis,
        }
    }

    return JsonResponse(result)


def chart_pie(request):
    """ 构造饼图的数据 """
    # 查询每种药品的总销售金额
    sales_data = models.Sales.objects.values('drug__name').annotate(total_sales=Sum('amount')).order_by('-total_sales')

    # 准备数据格式
    db_data_list = [
        {"value": item['total_sales'], "name": item['drug__name']}
        for item in sales_data
    ]

    result = {
        "status": True,
        "data": db_data_list
    }
    return JsonResponse(result)

class DoctorModelForm(BootStrapModelForm):
    class Meta:
        model = models.Doctor
        exclude = ["modify_time"]


def doctor_list(request):
    data_dict = {}
    search_data = request.GET.get('q', "")
    if search_data:
        data_dict["name__contains"] = search_data
    queryset = models.Doctor.objects.filter(**data_dict).order_by('id')
    page_object = Pagination(request, queryset)
    form = DoctorModelForm()
    context = {
        'form': form,
        "queryset": page_object.page_queryset,  # 分完页的数据
        "page_string": page_object.html()  # 生成页码
    }
    return render(request, 'm_doctor_list.html', context)

@csrf_exempt
def doctor_add(request):
    """ 新建订单（Ajax请求）"""
    form = DoctorModelForm(data=request.POST)
    if form.is_valid():
        # 处方日期
        form.instance.modify_time = now()

        # 保存到数据库中
        form.save()
        return JsonResponse({"status": True})
    return JsonResponse({"status": False, 'error': form.errors})

def doctor_delete(request):
    """ 删除订单 """
    uid = request.GET.get('uid')
    exists = models.Doctor.objects.filter(id=uid).exists()
    if not exists:
        return JsonResponse({"status": False, 'error': "删除失败，数据不存在。"})

    models.Doctor.objects.filter(id=uid).delete()
    return JsonResponse({"status": True})

@csrf_exempt
def doctor_edit(request):
    """ 编辑订单 """
    uid = request.GET.get("uid")
    row_object = models.Doctor.objects.filter(id=uid).first()
    if not row_object:
        return JsonResponse({"status": False, 'tips': "数据不存在，请刷新重试。"})

    form = DoctorModelForm(data=request.POST, instance=row_object)
    if form.is_valid():
        # 处方日期
        form.instance.modify_time = now()

        form.save()
        return JsonResponse({"status": True})

    return JsonResponse({"status": False, 'error': form.errors})


def doctor_detail(request):
    uid = request.GET.get("uid")
    row_dict = models.Doctor.objects.filter(id=uid).values('name', 'specialty', 'gender', 'phone', 'address', 'experience', 'user').first()
    if not row_dict:
        return JsonResponse({"status": False, 'error': "数据不存在。"})

    # 从数据库中获取到一个对象 row_object
    result = {
        "status": True,
        "data": row_dict
    }
    return JsonResponse(result)


class JanitorModelForm(BootStrapModelForm):
    class Meta:
        model = models.Warehouser
        exclude = ["modify_time"]


def janitor_list(request):
    data_dict = {}
    search_data = request.GET.get('q', "")
    if search_data:
        data_dict["name__contains"] = search_data
    queryset = models.Warehouser.objects.filter(**data_dict).order_by('id')
    page_object = Pagination(request, queryset)
    form = JanitorModelForm()
    context = {
        'form': form,
        "queryset": page_object.page_queryset,  # 分完页的数据
        "page_string": page_object.html()  # 生成页码
    }
    return render(request, 'm_janitor_list.html', context)

@csrf_exempt
def janitor_add(request):
    """ 新建订单（Ajax请求）"""
    form = JanitorModelForm(data=request.POST)
    if form.is_valid():
        # 处方日期
        form.instance.modify_time = now()

        # 保存到数据库中
        form.save()
        return JsonResponse({"status": True})
    return JsonResponse({"status": False, 'error': form.errors})

def janitor_delete(request):
    """ 删除订单 """
    uid = request.GET.get('uid')
    exists = models.Warehouser.objects.filter(id=uid).exists()
    if not exists:
        return JsonResponse({"status": False, 'error': "删除失败，数据不存在。"})

    models.Warehouser.objects.filter(id=uid).delete()
    return JsonResponse({"status": True})

@csrf_exempt
def janitor_edit(request):
    """ 编辑订单 """
    uid = request.GET.get("uid")
    row_object = models.Warehouser.objects.filter(id=uid).first()
    if not row_object:
        return JsonResponse({"status": False, 'tips': "数据不存在，请刷新重试。"})

    form = JanitorModelForm(data=request.POST, instance=row_object)
    if form.is_valid():
        # 处方日期
        form.instance.modify_time = now()

        form.save()
        return JsonResponse({"status": True})

    return JsonResponse({"status": False, 'error': form.errors})


def janitor_detail(request):
    uid = request.GET.get("uid")
    row_dict = models.Warehouser.objects.filter(id=uid).values('name', 'gender', 'phone', 'address', 'experience', 'user', 'inventory').first()
    if not row_dict:
        return JsonResponse({"status": False, 'error': "数据不存在。"})

    # 从数据库中获取到一个对象 row_object
    result = {
        "status": True,
        "data": row_dict
    }
    return JsonResponse(result)

