import json
import random
from datetime import datetime
from django.shortcuts import render, HttpResponse, get_object_or_404, redirect
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.utils.timezone import now
from django.db.models import F


from app_pharmacy import models
from app_pharmacy.utils.bootstrap import BootStrapModelForm
from app_pharmacy.utils.pagination import Pagination
from django.utils.safestring import mark_safe



class SupplierModelForm(BootStrapModelForm):
    class Meta:
        model = models.Supplier
        exclude = ["quali_date"]


def supplier_add(request):
    """ 添加靓号 """
    if request.method == "GET":
        form = SupplierModelForm()
        return render(request, 'w_supplier_add.html', {"form": form})

    form = SupplierModelForm(data=request.POST)
    form.instance.quali_date = now()
    if form.is_valid():
        form.save()
        return redirect('/supplier/list/')
    return render(request, 'w_supplier_add.html', {"form": form})

def supplier_delete(request):
    """ 删除供应商 """
    uid = request.GET.get('uid')
    exists = models.Supplier.objects.filter(id=uid).exists()
    if not exists:
        return JsonResponse({"status": False, 'error': "删除失败，数据不存在。"})

    models.Supplier.objects.filter(id=uid).delete()
    return JsonResponse({"status": True})


def supplier_detail(request):
    """ 根据ID获取供应商详细 """
    uid = request.GET.get("uid")
    row_dict = models.Supplier.objects.filter(id=uid).values("name", 'address', 'phone', 'email', 'detail', 'quali_status').first()
    if not row_dict:
        return JsonResponse({"status": False, 'error': "数据不存在。"})

    # 从数据库中获取到一个对象 row_object
    result = {
        "status": True,
        "data": row_dict
    }
    return JsonResponse(result)


@csrf_exempt
def supplier_edit(request):
    """ 编辑供应商 """
    uid = request.GET.get("uid")
    row_object = models.Supplier.objects.filter(id=uid).first()
    if not row_object:
        return JsonResponse({"status": False, 'tips': "数据不存在，请刷新重试。"})

    form = SupplierModelForm(data=request.POST, instance=row_object)
    if form.is_valid():
        form.instance.quali_date = now()
        form.save()
        return JsonResponse({"status": True})

    return JsonResponse({"status": False, 'error': form.errors})


def supplier_list(request):
    data_dict = {}
    search_data = request.GET.get('q', "")
    if search_data:
        data_dict["name__contains"] = search_data
    queryset = models.Supplier.objects.filter(**data_dict).order_by('id')
    page_object = Pagination(request, queryset)
    form = SupplierModelForm()
    context = {
        'form': form,
        "queryset": page_object.page_queryset,  # 分完页的数据
        "page_string": page_object.html()  # 生成页码
    }

    return render(request, 'w_supplier_list.html', context)

class OrderModelForm(BootStrapModelForm):
    class Meta:
        model = models.Order
        fields = "__all__"

def order_list(request):
    queryset = models.Order.objects.all().order_by('id')
    page_object = Pagination(request, queryset)
    form = OrderModelForm()
    context = {
        'form': form,
        "queryset": page_object.page_queryset,  # 分完页的数据
        "page_string": page_object.html()  # 生成页码
    }

    return render(request, 'w_order_list.html', context)

class InventoryModelForm(BootStrapModelForm):
    class Meta:
        model = models.Inventory
        exclude = ["modify_time"]


def inventory_list(request):
    """筛选库存信息"""
    current_date = now().date()

    # 筛选库存中药品数量低于警戒数量的药品
    low_stock_queryset = models.Drug.objects.filter(inventory__reorder__gt=F('inventory__quantity')).order_by('id')

    # 筛选库存中的过期药品
    expired_queryset = models.Drug.objects.filter(inventory__expiry__lt=current_date).order_by('id')

    # 筛选既没有过期又没有低于库存警戒数量的药品
    normal_queryset = models.Drug.objects.filter(inventory__quantity__gte=F('inventory__reorder'),
                                                 inventory__expiry__gte=current_date).order_by('id')

    page_object = Pagination(request, normal_queryset)
    form = InventoryModelForm()
    context = {
        'form': form,
        "low_stock_queryset": low_stock_queryset,
        "expired_queryset": expired_queryset,
        "normal_queryset": page_object.page_queryset,  # 分完页的数据
        "page_string": page_object.html()  # 生成页码
    }

    return render(request, 'w_inventory_list.html', context)


@csrf_exempt
def inventory_add(request):
    """ 新建订单（Ajax请求）"""
    form = InventoryModelForm(data=request.POST)
    if form.is_valid():
        # 保存到数据库中
        form.instance.modify_time = now()
        form.save()
        return JsonResponse({"status": True})
    return JsonResponse({"status": False, 'error': form.errors})

def inventory_delete(request):
    """ 药品出库 """
    uid = request.GET.get('uid')
    exists = models.Inventory.objects.filter(id=uid).exists()
    if not exists:
        return JsonResponse({"status": False, 'error': "删除失败，数据不存在。"})

    models.Inventory.objects.filter(id=uid).delete()
    return JsonResponse({"status": True})


@csrf_exempt
def inventory_edit(request):
    """ 编辑订单 """
    uid = request.GET.get("uid")
    row_object = models.Inventory.objects.filter(id=uid).first()
    if not row_object:
        return JsonResponse({"status": False, 'tips': "数据不存在，请刷新重试。"})

    form = InventoryModelForm(data=request.POST, instance=row_object)
    if form.is_valid():
        # 处方日期
        form.instance.modify_time = now()

        form.save()
        return JsonResponse({"status": True})

    return JsonResponse({"status": False, 'error': form.errors})


def inventory_detail(request):
    uid = request.GET.get("uid")
    row_dict = models.Inventory.objects.filter(id=uid).values('quantity', 'location', 'storage', 'reorder', 'expiry').first()
    if not row_dict:
        return JsonResponse({"status": False, 'error': "数据不存在。"})

    # 从数据库中获取到一个对象 row_object
    result = {
        "status": True,
        "data": row_dict
    }
    return JsonResponse(result)


def inventory_increase(request):
    if request.method == "GET":
        form = InventoryModelForm()
        return render(request, 'w_inventory_increase.html', {"form": form})

    form = InventoryModelForm(data=request.POST)
    form.instance.modify_time = now()
    if form.is_valid():
        form.save()
        return redirect('/pill/list/')
    return render(request, 'w_inventory_increase.html', {"form": form})


@csrf_exempt
def order_add(request):
    """ 新建订单（Ajax请求）"""
    form = OrderModelForm(data=request.POST)
    if form.is_valid():
        # 保存订单到数据库中
        order = form.save()

        # 更新库存数量
        drug_inventory = order.drug.inventory
        drug_inventory.quantity += order.number
        drug_inventory.save()

        return JsonResponse({"status": True})
    return JsonResponse({"status": False, 'error': form.errors})


def order_delete(request):
    """ 删除订单 """
    uid = request.GET.get('uid')
    exists = models.Order.objects.filter(id=uid).exists()
    if not exists:
        return JsonResponse({"status": False, 'error': "删除失败，数据不存在。"})

    models.Order.objects.filter(id=uid).delete()
    return JsonResponse({"status": True})





