import json
import random
from datetime import datetime
from django.shortcuts import render, HttpResponse, redirect
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from decimal import Decimal, ROUND_HALF_UP
from django.utils.timezone import now

from app_pharmacy import models
from app_pharmacy.utils.bootstrap import BootStrapModelForm
from app_pharmacy.utils.pagination import Pagination
from django.utils.safestring import mark_safe

class DrugModelForm(BootStrapModelForm):
    class Meta:
        model = models.Drug
        fields = "__all__"
        # fields = [""]
        # exclude = ["oid", 'admin']

class OrderModelForm(BootStrapModelForm):
    class Meta:
        model = models.Order
        fields = "__all__"


class SalesModelForm(BootStrapModelForm):
    class Meta:
        model = models.Sales
        exclude = ["date"]

    def __init__(self, *args, **kwargs):
        super(SalesModelForm, self).__init__(*args, **kwargs)

        # 将特定字段设置为只读
        self.fields['drug'].widget.attrs['readonly'] = True

        self.fields['amount'].widget.attrs['readonly'] = True

        self.fields['tax'].widget.attrs['readonly'] = True


def drug_list(request):
    data_dict = {}
    search_data = request.GET.get('q', "")
    if search_data:
        data_dict["name__contains"] = search_data

    queryset = models.Drug.objects.filter(**data_dict).order_by('-id')

    page_object = Pagination(request, queryset)
    form = SalesModelForm()
    context = {
        "search_data": search_data,
        'form': form,
        "queryset": page_object.page_queryset,  # 分完页的数据
        "page_string": page_object.html()  # 生成页码
    }

    return render(request, 'p_drug_list.html', context)

class PrescriptionModelForm(BootStrapModelForm):
    class Meta:
        model = models.Prescription
        fields = "__all__"

def prescription_info(request):
    user_info = request.session.get("info")
    user_id = user_info.get('id')

    patient_ids = models.Patient.objects.filter(user=user_id).values_list('id', flat=True)
    data_dic = {'patient__id__in': patient_ids}
    queryset = models.Prescription.objects.filter(**data_dic).order_by('id')


    page_object = Pagination(request, queryset)
    form = PrescriptionModelForm()
    context = {
        'form': form,
        "queryset": page_object.page_queryset,  # 分完页的数据
        "page_string": page_object.html()  # 生成页码
    }

    return render(request, 'p_prescription.html', context)

def drug_detail(request):
    """ 根据ID获取药品详细 """
    uid = request.GET.get("uid")
    row_dict = models.Drug.objects.filter(id=uid).values("id", "price", "inventory__quantity").first()
    if not row_dict:
        return JsonResponse({"status": False, 'error': "数据不存在。"})

    if row_dict['inventory__quantity'] <= 0:
        return JsonResponse({"status": False, 'error': "库存数量不足。"})

    tax = row_dict['price'] * Decimal('0.1')
    tax = tax.quantize(Decimal('0.01'), rounding=ROUND_HALF_UP)
    row_dict['price'] = (row_dict['price'] - tax).quantize(Decimal('0.01'), rounding=ROUND_HALF_UP)
    # 从数据库中获取到一个对象 row_object
    result = {
        "status": True,
        "data": row_dict,
        "tax": tax
    }
    return JsonResponse(result)


def drug_info(request):
    """ 根据ID获取药品信息 """
    uid = request.GET.get("uid")
    row_dict = models.Drug.objects.filter(id=uid).values("dose", "effect").first()
    if not row_dict:
        return JsonResponse({"status": False, 'error': "数据不存在。"})
    # 从数据库中获取到一个对象 row_object
    result = {
        "status": True,
        "data": row_dict,
    }
    return JsonResponse(result)

@csrf_exempt
def drug_purchase(request):
    """ 保存订单 """
    form = SalesModelForm(data=request.POST)
    form.instance.date = now()
    if form.is_valid():
        # 在保存之前，检查库存是否充足
        drug_id = form.cleaned_data.get('drug').id
        drug_inventory = form.cleaned_data.get('drug').inventory
        if drug_inventory.quantity <= 0:
            return JsonResponse({"status": False, 'error': "库存数量不足。"})

        # 减少库存数量
        drug_inventory.quantity -= 1
        drug_inventory.save()

        # 保存订单
        form.save()
        return JsonResponse({"status": True})
    return JsonResponse({"status": False, 'error': form.errors})






