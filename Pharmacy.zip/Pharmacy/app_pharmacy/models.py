from django.db import models
from django.db.models import F

# Create your models here.
class Drug(models.Model):
    """ 药品表 """
    name = models.CharField(verbose_name="药品名", max_length=32)
    category = models.ForeignKey(verbose_name="类别", to="Category", to_field="id", null=True, on_delete=models.SET_NULL)
    supplier = models.ForeignKey(verbose_name="供应商", to="Supplier", to_field="id", null=True, on_delete=models.SET_NULL)
    dose = models.CharField(verbose_name="推荐剂量", max_length=32)
    effect = models.CharField(verbose_name="疗效", max_length=128)
    price = models.DecimalField(verbose_name="价格", max_digits=10, decimal_places=2, default=0)
    inventory = models.ForeignKey(verbose_name="库存", to="Inventory", to_field="id", on_delete=models.CASCADE)
    modify_time = models.DateField(verbose_name="修改时间")
    def __str__(self):
        return self.name

class Patient(models.Model):
    """患者表"""
    name = models.CharField(verbose_name="患者姓名", max_length=32)
    user = models.ForeignKey(verbose_name="关联账号", to="User", to_field="id", on_delete=models.CASCADE)
    birthday = models.DateField(verbose_name="出生日期")
    gender_choices = (
        (1, "男"),
        (2, "女"),
    )
    gender = models.SmallIntegerField(verbose_name="性别", choices=gender_choices)
    ethnicity = models.CharField(verbose_name="民族", max_length=8)
    phone = models.CharField(verbose_name="电话", max_length=11)
    address = models.CharField(verbose_name="地址", max_length=128)
    history = models.CharField(verbose_name="病史", max_length=128)
    modify_time = models.DateTimeField(verbose_name="更改时间")
    def __str__(self):
        return self.name

class Doctor(models.Model):
    """医生表"""
    name = models.CharField(verbose_name="医生姓名", max_length=32)
    user = models.ForeignKey(verbose_name="关联账号", to="User", to_field="id", on_delete=models.CASCADE)
    specialty = models.CharField(verbose_name="专科", max_length=16)
    gender_choices = (
        (1, "男"),
        (2, "女"),
    )
    gender = models.SmallIntegerField(verbose_name="性别", choices=gender_choices)
    phone = models.CharField(verbose_name="电话", max_length=11)
    address = models.CharField(verbose_name="地址", max_length=128)
    experience = models.IntegerField(verbose_name="从业年数")
    modify_time = models.DateTimeField(verbose_name="更改时间")
    def __str__(self):
        return self.name

class Warehouser(models.Model):
    name = models.CharField(verbose_name="库房管理员姓名", max_length=32)
    inventory = models.ForeignKey(verbose_name="管理仓库", to="Inventory", to_field="id", on_delete=models.CASCADE, default=1)
    user = models.ForeignKey(verbose_name="关联账号", to="User", to_field="id", on_delete=models.CASCADE)
    gender_choices = (
        (1, "男"),
        (2, "女"),
    )
    gender = models.SmallIntegerField(verbose_name="性别", choices=gender_choices)
    phone = models.CharField(verbose_name="电话", max_length=11)
    address = models.CharField(verbose_name="地址", max_length=128)
    experience = models.IntegerField(verbose_name="从业年数")
    modify_time = models.DateTimeField(verbose_name="更改时间")
    def __str__(self):
        return self.name

class Prescription(models.Model):
    """处方表"""
    patient = models.ForeignKey(verbose_name="患者", to="Patient", to_field="id", on_delete=models.CASCADE)
    doctor = models.ForeignKey(verbose_name="医生", to="Doctor", to_field="id", on_delete=models.CASCADE)
    date = models.DateTimeField(verbose_name="开具日期")
    notes = models.CharField(verbose_name="备注", max_length=128)
    medication = models.CharField(verbose_name="药品名称", max_length=128)

class Supplier(models.Model):
    """供应商表"""
    name = models.CharField(verbose_name="供应商名称", max_length=32)
    address = models.CharField(verbose_name="地址", max_length=128)
    phone = models.CharField(verbose_name="电话", max_length=11)
    email = models.CharField(verbose_name="邮箱", max_length=32)
    detail = models.CharField(verbose_name="详细信息", max_length=128)
    quali_choices = (
        (1, "合格"),
        (2, "不合格"),
    )
    quali_status = models.SmallIntegerField(verbose_name="资格状态", choices=quali_choices)
    quali_date = models.DateField(verbose_name="上一次检查日期")
    def __str__(self):
        return self.name

class Sales(models.Model):
    """销售记录表"""
    patient = models.ForeignKey(verbose_name="患者", to="Patient", to_field="id", on_delete=models.CASCADE)
    doctor = models.ForeignKey(verbose_name="医生", to="Doctor", to_field="id", on_delete=models.CASCADE)
    drug = models.ForeignKey(verbose_name="药品", to="Drug", to_field="id", on_delete=models.CASCADE)
    date = models.DateTimeField(verbose_name="销售日期")
    amount = models.DecimalField(verbose_name="总金额", max_digits=10, decimal_places=2, default=0)
    payment = models.CharField(verbose_name="支付方式", max_length=8)
    tax = models.DecimalField(verbose_name="税费", max_digits=10, decimal_places=2, default=0)



class Order(models.Model):
    """采购订单表"""
    supplier = models.ForeignKey(verbose_name="供应商", to="Supplier", to_field="id", on_delete=models.CASCADE)
    drug = models.ForeignKey(verbose_name="药品", to="Drug", to_field="id", on_delete=models.CASCADE)
    number = models.IntegerField(verbose_name="采购数量")
    date = models.DateField(verbose_name="采购日期")
    amount = models.DecimalField(verbose_name="总金额", max_digits=10, decimal_places=2, default=0)
    delivery = models.DateField(verbose_name="到货日期")
    batch = models.CharField(verbose_name="生产批号", max_length=64)


class Inventory(models.Model):
    """库存记录表"""
    expiry = models.DateField(verbose_name="有效日期")
    reorder = models.IntegerField(verbose_name="预警数量")
    storage = models.CharField(verbose_name="存储条件", max_length=64)
    quantity = models.IntegerField(verbose_name="数量")
    location = models.CharField(verbose_name="存放地点", max_length=64)
    modify_time = models.DateTimeField(verbose_name="更改时间")
    def __str__(self):
        return self.location

class User(models.Model):
    """用户表"""
    username = models.CharField(verbose_name="用户名", max_length=32)
    password = models.CharField(verbose_name="密码", max_length=128)
    role_choices = (
        (1, "患者"),
        (2, "医生"),
        (3, "仓库管理员"),
        (4, "药房老板"),
    )
    role = models.SmallIntegerField(verbose_name="角色", choices=role_choices)
    def __str__(self):
        return self.username

class Category(models.Model):
    """ 药品分类表 """
    name = models.CharField(verbose_name="分类名称", max_length=32)
    description = models.CharField(verbose_name="分类描述", max_length=64)

    access_choices = (
        (1, "大众级"),
        (2, "医生级"),
        (3, "特权级"),
    )

    access = models.SmallIntegerField(verbose_name="权限需求", choices=access_choices)
    doctor = models.ForeignKey(verbose_name="看管医生", to="Doctor", to_field="id", on_delete=models.CASCADE)
    modify_time = models.DateTimeField(verbose_name="更改时间")

    def __str__(self):
        return self.name


















