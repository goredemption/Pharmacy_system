"""
URL configuration for Pharmacy project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path, re_path
from django.views.static import serve
from django.conf import settings

from app_pharmacy.views import account, patient, doctor, warehouse, manager

urlpatterns = [
    # 登陆系统
    path('preface/', account.preface),
    path('login/', account.login),
    path('logout/', account.logout),
    path('image/code/', account.image_code),
    path('signup/', account.signup),

    # 患者功能模块
    path('drug/list/', patient.drug_list),
    path('prescription/info/', patient.prescription_info),
    path('drug/detail/', patient.drug_detail),
    path('drug/purchase/', patient.drug_purchase),
    path('drug/info/', patient.drug_info),

    # 医生功能模块
    path('patient/list/', doctor.patient_list),
    path('prescribe/', doctor.prescribe),
    path('drug/sort/', doctor.drug_sort),
    path('patient/add/', doctor.patient_add),
    path('patient/<int:nid>/edit/', doctor.patient_edit),
    path('patient/<int:nid>/delete/', doctor.patient_delete),
    path('prescription/add/', doctor.prescription_add),
    path('prescription/delete/', doctor.prescription_delete),
    path('prescription/detail/', doctor.prescription_detail),
    path('prescription/edit/', doctor.prescription_edit),
    path('drug_sort/add/', doctor.drug_sort_add),
    path('drug_sort/delete/', doctor.drug_sort_delete),
    path('drug_sort/detail/', doctor.drug_sort_detail),
    path('drug_sort/edit/', doctor.drug_sort_edit),
    path('pill/list/', doctor.pill_list),
    path('pill/add/', doctor.pill_add),
    path('pill/delete/', doctor.pill_delete),
    path('pill/detail/', doctor.pill_detail),
    path('pill/edit/', doctor.pill_edit),

    # 仓库管理员模块
    path('supplier/list/', warehouse.supplier_list),
    path('supplier/add/', warehouse.supplier_add),
    path('supplier/edit/', warehouse.supplier_edit),
    path('supplier/delete/', warehouse.supplier_delete),
    path('supplier/detail/', warehouse.supplier_detail),
    path('order/list/', warehouse.order_list),
    path('order/add/', warehouse.order_add),
    path('order/delete/', warehouse.order_delete),
    path('inventory/list/', warehouse.inventory_list),
    path('inventory/delete/', warehouse.inventory_delete),
    path('inventory/increase/', warehouse.inventory_increase),
    path('inventory/add/', warehouse.inventory_add),
    path('inventory/edit/', warehouse.inventory_edit),
    path('inventory/detail/', warehouse.inventory_detail),



    # 药房老板模块
    path('sales/list/', manager.sales_list),
    path('user/list/', manager.user_list),
    path('user/edit/', manager.user_edit),
    path('user/delete/', manager.user_delete),
    path('user/detail/', manager.user_detail),
    path('chart/bar/', manager.chart_bar),
    path('chart/pie/', manager.chart_pie),
    path('drug/bar/', manager.drug_bar),
    path('doctor/list/', manager.doctor_list),
    path('doctor/add/', manager.doctor_add),
    path('doctor/delete/', manager.doctor_delete),
    path('doctor/detail/', manager.doctor_detail),
    path('doctor/edit/', manager.doctor_edit),
    path('janitor/list/', manager.janitor_list),
    path('janitor/add/', manager.janitor_add),
    path('janitor/delete/', manager.janitor_delete),
    path('janitor/detail/', manager.janitor_detail),
    path('janitor/edit/', manager.janitor_edit),
]
